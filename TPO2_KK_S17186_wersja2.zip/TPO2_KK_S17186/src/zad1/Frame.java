package zad1;

import java.awt.*;
import javax.swing.*;

public class Frame {
	
    
	public static void open(String JSON_weather_response, Double rate1, Double rate2, String city_name) {
		
		// Initialize elements
		JFrame frame = new JFrame("TPO - zad.2");
		JButton weather_btn = new JButton("Weather API");
		JButton rate1_btn = new JButton("Rate1");
		JButton rate2_btn = new JButton("Rate2");
		JButton webpage_btn = new JButton("Webpage");		
		GridBagConstraints gbc = new GridBagConstraints();
		JPanel buttons_panel = new JPanel(new GridBagLayout());
		JTextArea text_area = new JTextArea();
		JFrame text_frame = new JFrame("Weather API response");		
		
		// Set action
		weather_btn.addActionListener(e -> {
			text_area.setText(JSON_weather_response);
			text_frame.setVisible(true);
				});
		rate1_btn.addActionListener(e -> {
			text_area.setText(rate1.toString());
			text_frame.setVisible(true);
				});
		rate2_btn.addActionListener(e -> {
			text_area.setText(rate2.toString());
			text_frame.setVisible(true);
				});
		webpage_btn.addActionListener(e -> {
			text_area.setText(city_name);
			text_frame.setVisible(true);
				});
		
		// Style elements
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);       
		buttons_panel.setBackground(Color.BLACK);		
		text_frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		text_frame.setMinimumSize(new Dimension(600, 600));
		text_frame.setLocationRelativeTo(null);		
		styleFrame(frame);		
		styleButton(weather_btn);
		styleButton(rate1_btn);
		styleButton(rate2_btn);
		styleButton(webpage_btn);
		styleTextArea(text_area);
		
		// Add and show elements
		text_frame.add(text_area);
		buttons_panel.add(weather_btn, gbc);
		buttons_panel.add(rate1_btn, gbc); 
		buttons_panel.add(rate2_btn, gbc);
		buttons_panel.add(webpage_btn, gbc);
		frame.add(buttons_panel); 
		frame.pack();
		frame.setVisible(true);
	}
	

//metody
	private static JFrame styleFrame(JFrame frame) {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setMinimumSize(new Dimension(1200, 1200));
		frame.setLocationRelativeTo(null);
		frame.setBackground(Color.BLACK);
		return frame; 
	}
	private static JButton styleButton(JButton btn) {
		btn.setPreferredSize(new Dimension(300, 100));
		btn.setFont(new Font("Comic Sans MS", Font.PLAIN, 40));
		btn.setMargin(new Insets(10, 10, 10, 10));
		btn.setBackground(Color.WHITE);
		btn.setFocusable(false);
		return btn; 
	}	
	private static JTextArea styleTextArea(JTextArea text_area) {
		text_area.setLineWrap(true);
		text_area.setBackground(Color.DARK_GRAY);
		text_area.setCaretColor(Color.WHITE);
		text_area.setForeground(Color.WHITE);
		text_area.setFont(new Font("Lucida Sans Typewriter", Font.PLAIN, 25));
		text_area.setSelectedTextColor(Color.BLACK);
		text_area.setSelectionColor(Color.LIGHT_GRAY);
		text_area.setMargin(new Insets(15, 15, 15, 15));
		return text_area;
	}
}
