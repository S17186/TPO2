/**
 *
 *  @author Korab Karolina S17186
 *
 */

package zad1;


public class Main {
  public static void main(String[] args) {
    Service s = new Service("Thailand");
    String weatherJson = s.getWeather("Warsaw");
    Double rate1 = s.getRateFor("USD");
    Double rate2 = s.getNBPRate();
    // ...
    // część uruchamiająca GUI    
	Frame.open(weatherJson, rate1, rate2, s.getCity());
  }
}
